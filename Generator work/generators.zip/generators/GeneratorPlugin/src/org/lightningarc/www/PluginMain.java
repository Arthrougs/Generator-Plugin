package org.lightningarc.www;


import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class PluginMain extends JavaPlugin{

	@Override
	public void onEnable(){
		Bukkit.getPluginManager().registerEvents(new PlayerEvents(), this);
	}
	
	@Override
	public void onDisable(){
		
	}
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
	  {
		return false;
	  }
	
}
